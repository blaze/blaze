import ucr

ucr.ed("Data.bin", "Query.bin", 128)
