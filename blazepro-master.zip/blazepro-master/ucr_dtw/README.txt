This is a porting of the implementation of the UCR algorithms for ED
(Euclidean Distance) and DTW (Dynamic Time Warping) as described in:

http://www.cs.ucr.edu/~eamonn/SIGKDD_trillion.pdf

The original sources are in C++ and can be found in:

http://www.cs.ucr.edu/~eamonn/UCRsuite.html

The implementation here is work in progress and help in refining it is welcome!

Francesc Alted
