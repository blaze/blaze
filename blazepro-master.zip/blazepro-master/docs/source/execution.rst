=========
Execution
=========

.. automodule:: ndtable.engine.execution
   :members:
